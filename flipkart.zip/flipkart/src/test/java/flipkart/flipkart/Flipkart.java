package flipkart.flipkart;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Flipkart {
	
	static WebDriver driver;
	
	  @BeforeTest
	    public void setup(){
	        WebDriverManager.chromedriver().setup();
	        ChromeOptions options = new ChromeOptions();
//			options.addArguments("--incognito");
	        options.addArguments("start-maximized");
	        driver=new ChromeDriver(options);
	    }
	    @Test
	    public void flipkart() throws InterruptedException {
	        Thread.sleep(1000);
	        driver.get("https://www.flipkart.com/");
	        Thread.sleep(1000);
	        driver.findElement(By.name("q")).sendKeys("Macbook air m2", Keys.ENTER);
//			driver.findElement(By.xpath("//button[@type='submit']")).click();
			driver.findElement(By.xpath("(//div[@class='col col-7-12'])[1]")).click();
			Thread.sleep(2000);
	        ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
	        driver.switchTo().window(tabs.get(1));
//			driver.findElement(By.name("password")).sendKeys("admin123");
	        Thread.sleep(2000);
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        js.executeScript("window.scrollBy(0,250)", "");
	        driver.findElement(By.xpath("//button[text()='Add to cart']")).click();
	        Thread.sleep(10000);
	    }
	    @AfterTest
	    public void tearDown(){
	        driver.quit();
	    }

}
